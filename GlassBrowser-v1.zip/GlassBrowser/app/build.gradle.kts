plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.glassbrowser"
    compileSdk = 34
    defaultConfig { applicationId = "com.glassbrowser"; minSdk = 26; targetSdk = 34; versionCode = 5; versionName = "1.0.0" }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false; checkReleaseBuilds = false }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.core:core-splashscreen:1.0.1")
}
