package com.glass.browser

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.app.KeyguardManager
import android.app.role.RoleManager
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.Settings
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.webkit.*
import android.widget.FrameLayout
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

private val YT = """(function(){if(window.__gy)return;window.__gy=1;var c=document.createElement('style');c.textContent='.ytp-ad-module,.ytp-ad-overlay-container,ytd-ad-slot-renderer,ytd-promoted-sparkles-web-renderer,#masthead-ad,ytm-promoted-sparkles-web-renderer,ytm-companion-slot,ytm-promoted-video-renderer,ad-slot-renderer,.ytp-ad-image-overlay{display:none!important}';(document.head||document.documentElement).appendChild(c);setInterval(function(){var v=document.querySelector('video');var a=document.querySelector('.ad-showing,.ytp-ad-player-overlay');if(v&&a){v.muted=true;if(isFinite(v.duration))v.currentTime=v.duration}var b=document.querySelector('.ytp-ad-skip-button,.ytp-skip-ad-button,.ytp-ad-skip-button-modern');if(b)b.click()},300)})()"""
private val READER = """(function(){var a=document.querySelector('article,main,[role=main]')||document.body;var h=a.innerHTML;document.body.innerHTML='<div style="max-width:680px;margin:auto;padding:20px;font:19px/1.6 Georgia,serif">'+h+'</div>';document.querySelectorAll('nav,header,footer,aside,script,iframe,form,button').forEach(function(e){e.remove()});document.body.style.background='#fff';document.body.style.color='#111'})()"""
private val BUILTIN = setOf("doubleclick.net","googlesyndication.com","googleadservices.com","google-analytics.com","googletagmanager.com","googletagservices.com","adservice.google.com","adnxs.com","taboola.com","outbrain.com","criteo.com","criteo.net","scorecardresearch.com","hotjar.com","moatads.com","amazon-adsystem.com","rubiconproject.com","pubmatic.com","openx.net","adsrvr.org","advertising.com","ads.yahoo.com","quantserve.com","2mdn.net","adform.net","smartadserver.com","casalemedia.com","mathtag.com","bluekai.com","krxd.net")

@SuppressLint("SetJavaScriptEnabled")
class MainActivity : Activity() {
    private val defs = JSONObject("""{"theme":"dark","gradient":"1","accent":"#0a84ff","blur":"24","sat":"180","radius":"24","text":"16","jelly":"1","toolbar":"docked","addr":"bottom","tabview":"grid","showFav":"1","showAI":"1","showRL":"1","showPR":"1","aiOn":"1","summ":"1","voice":"1","safe":"2","cookies":"1","block":"1","https":"1","lockPriv":"0","popups":"1","dnt":"1","cbanner":"1","engine":"3","permCam":"ask","permMic":"ask","permLoc":"ask","hz":"1","desk":"0","dark":"0","askSave":"0","zoom":"100","auto":"1"}""")
    private lateinit var sp: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var holder: FrameLayout
    private lateinit var ui: WebView
    private val tabs = ArrayList<Tab>()
    private var cur = 0
    private var blocked = 0
    private var pageBlk = 0
    private var curMode = "ui"
    private var strip = 138
    private var pendingUrl: String? = null
    @Volatile private var hosts: Set<String> = emptySet()
    private var fsView: View? = null
    private var fsCb: WebChromeClient.CustomViewCallback? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var permReq: PermissionRequest? = null
    private var geoCb: GeolocationPermissions.Callback? = null
    private var geoOrigin = ""

    inner class PW(c: Context) : WebView(c) {
        override fun onScrollChanged(l: Int, t: Int, ol: Int, ot: Int) {
            super.onScrollChanged(l, t, ol, ot)
            if (tabs.getOrNull(cur)?.web === this) runUi("sd(${t - ot})")
        }
    }
    inner class Tab(val web: PW, val priv: Boolean) { var title = "New Tab"; var url = ""; var desk = false }

    private fun S(k: String): String = sp.getString(k, null) ?: defs.optString(k)
    private fun runUi(js: String) = runOnUiThread { ui.evaluateJavascript(js, null) }
    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")
    private fun q(s: String) = JSONObject.quote(s)
    private fun isCur(t: Tab) = tabs.getOrNull(cur) === t
    private fun http(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 25000
        c.setRequestProperty("User-Agent", "GlassBrowser/" + BuildConfig.VERSION_NAME)
        if (c.responseCode != 200) throw Exception("HTTP " + c.responseCode)
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sp = getSharedPreferences("s", 0)
        root = FrameLayout(this); root.fitsSystemWindows = true
        holder = FrameLayout(this)
        root.addView(holder, FrameLayout.LayoutParams(-1, -1))
        ui = WebView(this)
        ui.setBackgroundColor(0)
        ui.settings.javaScriptEnabled = true
        ui.settings.domStorageEnabled = true
        ui.webChromeClient = Dlg()
        ui.addJavascriptInterface(Bridge(), "AndroidNative")
        root.addView(ui, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        pendingUrl = intent?.dataString
        applyHz(); loadHosts(); openTab(false); layout()
        ui.loadUrl("file:///android_asset/index.html")
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 12)
        if (S("auto") == "1") checkUpdate(true)
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        i.dataString?.let { runUi("go(${q(it)})") }
    }

    private fun applyHz() {
        val p = window.attributes
        p.preferredRefreshRate = if (S("hz") == "1") 120f else 60f
        window.attributes = p
    }

    private fun layout() {
        val h = (strip * resources.displayMetrics.density).toInt()
        val top = S("addr") == "top"
        val page = curMode == "page"
        val lp = FrameLayout.LayoutParams(-1, if (page) h else -1)
        lp.gravity = if (page && top) Gravity.TOP else Gravity.BOTTOM
        ui.layoutParams = lp
        val hp = FrameLayout.LayoutParams(-1, -1)
        if (page) { if (top) hp.topMargin = h else hp.bottomMargin = h }
        holder.layoutParams = hp
        holder.visibility = if (curMode == "ui") View.INVISIBLE else View.VISIBLE
    }

    /* ---------- tabs ---------- */
    private fun openTab(priv: Boolean) {
        val w = PW(this); val t = Tab(w, priv)
        val s = w.settings
        s.javaScriptEnabled = true; s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.setSupportMultipleWindows(false)
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.builtInZoomControls = true; s.displayZoomControls = false
        s.useWideViewPort = true; s.loadWithOverviewMode = true
        s.setGeolocationEnabled(true)
        if (priv) s.cacheMode = WebSettings.LOAD_NO_CACHE
        w.webViewClient = client(t); w.webChromeClient = Chrome(t)
        w.setDownloadListener { u, ua, cd, mime, _ -> download(u, ua, cd, mime) }
        tabs.add(t); applyPrefs(t); select(tabs.size - 1)
    }
    private fun select(i: Int) {
        cur = i; holder.removeAllViews()
        holder.addView(tabs[i].web, FrameLayout.LayoutParams(-1, -1))
    }
    private fun isDesk(t: Tab) = t.desk || S("desk") == "1"
    private fun deskUa(): String {
        val v = Regex("Chrome/([\\d.]+)").find(WebSettings.getDefaultUserAgent(this))?.groupValues?.get(1) ?: "120.0.0.0"
        return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$v Safari/537.36"
    }
    @Suppress("DEPRECATION")
    private fun applyPrefs(t: Tab) {
        val s = t.web.settings
        s.textZoom = S("zoom").toIntOrNull() ?: 100
        s.javaScriptCanOpenWindowsAutomatically = S("popups") != "1"
        s.userAgentString = if (isDesk(t)) deskUa() else null
        s.forceDark = if (S("dark") == "1") WebSettings.FORCE_DARK_ON else WebSettings.FORCE_DARK_AUTO
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(S("cookies") != "2")
        cm.setAcceptThirdPartyCookies(t.web, S("cookies") == "0")
    }

    /* ---------- web clients ---------- */
    private fun isBlocked(host: String): Boolean {
        var h = host
        while (h.contains('.')) { if (hosts.contains(h) || BUILTIN.contains(h)) return true; h = h.substringAfter('.') }
        return false
    }
    private fun css(sel: String) = "(function(){var s=document.createElement('style');s.textContent='$sel{display:none!important}';(document.head||document.documentElement).appendChild(s)})()"
    private fun inject(v: WebView, u: String) {
        if (S("cbanner") == "1") v.evaluateJavascript(css("#onetrust-banner-sdk,.cc-window,#CybotCookiebotDialog,.fc-consent-root,#cookie-banner,.cookie-banner,[id*=cookie-consent],[class*=cookie-consent]"), null)
        if (S("block") == "1" && u.contains("youtube.com")) v.evaluateJavascript(YT, null)
        try {
            val a = JSONArray(sp.getString("us", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i); val m = o.optString("m", "*")
                if (o.optBoolean("on", true) && (m == "*" || u.contains(m))) v.evaluateJavascript(o.getString("c"), null)
            }
        } catch (e: Exception) { }
    }
    private fun client(t: Tab) = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
            val u = r.url; val sc = u.scheme ?: ""
            if (sc == "http" && S("https") == "1" && u.host != "localhost") { v.loadUrl(u.toString().replaceFirst("http://", "https://")); return true }
            if (sc == "http" || sc == "https" || sc == "about" || sc == "data" || sc == "blob" || sc == "javascript") return false
            try { startActivity(Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME).addCategory(Intent.CATEGORY_BROWSABLE)) } catch (e: Exception) { }
            return true
        }
        override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
            if (S("block") == "1" && !r.isForMainFrame) {
                val h = r.url.host ?: ""; val p = r.url.path ?: ""
                val yt = h.endsWith("youtube.com") && (p.contains("/pagead/") || p.contains("/api/stats/ads") || p.contains("/ptracking") || p.contains("get_midroll"))
                if (yt || isBlocked(h)) { blocked++; pageBlk++; return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0))) }
            }
            return null
        }
        override fun onPageStarted(v: WebView, u: String, f: Bitmap?) { pageBlk = 0; t.url = u; if (isCur(t)) runUi("pp(8)") }
        override fun doUpdateVisitedHistory(v: WebView, u: String, r: Boolean) {
            t.url = u
            if (isCur(t)) runUi("pi(${q(u)},${q(v.title ?: "")},${if (t.priv) 1 else 0})")
        }
        override fun onPageFinished(v: WebView, u: String) { t.url = u; if (isCur(t)) runUi("pp(100)"); inject(v, u) }
        override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
            if (r.isForMainFrame) v.loadDataWithBaseURL(r.url.toString(), "<meta name=viewport content='width=device-width'><body style='font:16px sans-serif;padding:40px;text-align:center'><h2>Can’t open this page</h2><p>${e.description}</p>", "text/html", "utf-8", null)
        }
    }
    open inner class Dlg : WebChromeClient() {
        override fun onJsAlert(v: WebView?, u: String?, m: String?, r: JsResult): Boolean {
            AlertDialog.Builder(this@MainActivity).setMessage(m).setPositiveButton("OK") { _, _ -> r.confirm() }.setOnCancelListener { r.cancel() }.show(); return true
        }
        override fun onJsConfirm(v: WebView?, u: String?, m: String?, r: JsResult): Boolean {
            AlertDialog.Builder(this@MainActivity).setMessage(m).setPositiveButton("OK") { _, _ -> r.confirm() }.setNegativeButton("Cancel") { _, _ -> r.cancel() }.setOnCancelListener { r.cancel() }.show(); return true
        }
    }
    inner class Chrome(val t: Tab) : Dlg() {
        override fun onProgressChanged(v: WebView, p: Int) { if (isCur(t)) runUi("pp($p)") }
        override fun onReceivedTitle(v: WebView, title: String?) {
            t.title = title ?: t.title
            if (isCur(t)) runUi("pi(${q(t.url)},${q(t.title)},${if (t.priv) 1 else 0})")
        }
        override fun onPermissionRequest(r: PermissionRequest) { runOnUiThread { askMedia(r) } }
        override fun onGeolocationPermissionsShowPrompt(o: String, cb: GeolocationPermissions.Callback) { runOnUiThread { askGeo(o, cb) } }
        override fun onShowFileChooser(v: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
            fileCb?.onReceiveValue(null); fileCb = cb
            return try { startActivityForResult(p.createIntent(), 5); true } catch (e: Exception) { fileCb = null; false }
        }
        @Suppress("DEPRECATION")
        override fun onShowCustomView(v: View, cb: CustomViewCallback) {
            fsView = v; fsCb = cb; root.addView(v, FrameLayout.LayoutParams(-1, -1)); ui.visibility = View.GONE
            window.decorView.systemUiVisibility = 0x1706
        }
        @Suppress("DEPRECATION")
        override fun onHideCustomView() {
            fsView?.let { root.removeView(it) }; fsView = null; fsCb?.onCustomViewHidden()
            ui.visibility = View.VISIBLE; window.decorView.systemUiVisibility = 0
        }
    }

    /* ---------- permissions ---------- */
    private fun askMedia(r: PermissionRequest) {
        val host = r.origin.host ?: ""
        val kinds = r.resources.mapNotNull { when (it) { PermissionRequest.RESOURCE_VIDEO_CAPTURE -> "cam"; PermissionRequest.RESOURCE_AUDIO_CAPTURE -> "mic"; else -> null } }
        if (kinds.isEmpty()) { r.deny(); return }
        val saved = kinds.map { sp.getString("site:$host|$it", null) }
        if (saved.any { it == "0" } || (saved.all { it == null } && kinds.any { S(if (it == "cam") "permCam" else "permMic") == "block" })) { r.deny(); return }
        if (saved.all { it == "1" }) { grantMedia(r, kinds); return }
        AlertDialog.Builder(this).setTitle(host)
            .setMessage("wants to use your " + kinds.joinToString(" and ") { if (it == "cam") "camera" else "microphone" })
            .setPositiveButton("Allow") { _, _ -> kinds.forEach { sp.edit().putString("site:$host|$it", "1").apply() }; grantMedia(r, kinds) }
            .setNegativeButton("Block") { _, _ -> kinds.forEach { sp.edit().putString("site:$host|$it", "0").apply() }; r.deny() }
            .setOnCancelListener { r.deny() }.show()
    }
    private fun grantMedia(r: PermissionRequest, kinds: List<String>) {
        val need = kinds.map { if (it == "cam") Manifest.permission.CAMERA else Manifest.permission.RECORD_AUDIO }
            .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isEmpty()) r.grant(r.resources) else { permReq = r; requestPermissions(need.toTypedArray(), 7) }
    }
    private fun askGeo(o: String, cb: GeolocationPermissions.Callback) {
        val host = Uri.parse(o).host ?: o; val k = "site:$host|loc"; val s = sp.getString(k, null)
        fun allow() {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) { geoCb = cb; geoOrigin = o; requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 8) }
            else cb.invoke(o, true, false)
        }
        if (s == "0" || (s == null && S("permLoc") == "block")) { cb.invoke(o, false, false); return }
        if (s == "1") { allow(); return }
        AlertDialog.Builder(this).setTitle(host).setMessage("wants to use your location")
            .setPositiveButton("Allow") { _, _ -> sp.edit().putString(k, "1").apply(); allow() }
            .setNegativeButton("Block") { _, _ -> sp.edit().putString(k, "0").apply(); cb.invoke(o, false, false) }
            .setOnCancelListener { cb.invoke(o, false, false) }.show()
    }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        val ok = r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }
        if (c == 7) { permReq?.let { if (ok) it.grant(it.resources) else it.deny() }; permReq = null }
        if (c == 8) { geoCb?.invoke(geoOrigin, ok, false); geoCb = null }
    }

    /* ---------- downloads, filters, AI, updates ---------- */
    private fun download(u: String, ua: String?, cd: String?, mime: String?) {
        try {
            val fn = URLUtil.guessFileName(u, cd, mime)
            val r = DownloadManager.Request(Uri.parse(u))
            if (ua != null) r.addRequestHeader("User-Agent", ua)
            CookieManager.getInstance().getCookie(u)?.let { r.addRequestHeader("Cookie", it) }
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fn)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
            val a = JSONArray(sp.getString("dls", "[]")); val n = JSONArray().put(JSONArray().put(fn).put(System.currentTimeMillis()))
            for (i in 0 until minOf(a.length(), 99)) n.put(a.get(i))
            sp.edit().putString("dls", n.toString()).apply(); toast("Downloading $fn")
        } catch (e: Exception) { toast("Download failed") }
    }
    private fun loadHosts() = thread {
        try {
            val f = File(filesDir, "hosts.txt")
            if (f.exists()) hosts = f.readLines().toHashSet() else updateFilters(false)
        } catch (e: Exception) { }
    }
    private fun updateFilters(manual: Boolean) = thread {
        try {
            val s = HashSet<String>()
            http("https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts").lineSequence().forEach { l ->
                if (l.startsWith("0.0.0.0 ")) { val h = l.substring(8).substringBefore('#').trim(); if (h.contains('.') && h != "0.0.0.0") s.add(h) }
            }
            if (s.size > 1000) { File(filesDir, "hosts.txt").writeText(s.joinToString("\n")); hosts = s; sp.edit().putLong("hts", System.currentTimeMillis()).apply() }
            if (manual) runUi("filtersDone(${q("Filters updated · ${s.size} domains")})")
        } catch (e: Exception) { if (manual) runUi("filtersDone('Update failed. Check your connection.')") }
    }
    private fun ai(query: String, fb: String?) = thread {
        var ans: String? = null
        for (i in 0..2) {
            try { val r = http("https://text.pollinations.ai/" + enc(query) + "?model=openai"); if (r.isNotBlank()) { ans = r; break } } catch (e: Exception) { Thread.sleep(1200L * (i + 1)) }
        }
        if (ans == null) try { ans = JSONObject(http("https://api.duckduckgo.com/?q=${enc(query.take(200))}&format=json&no_html=1&skip_disambig=1")).optString("AbstractText").ifBlank { null } } catch (e: Exception) { }
        if (ans == null) try { ans = JSONObject(http("https://en.wikipedia.org/api/rest_v1/page/summary/${enc(query.trim().take(100))}")).optString("extract").ifBlank { null } } catch (e: Exception) { }
        runUi("aiReply(${q(ans ?: fb ?: "Couldn’t reach an AI service. Check your connection and try again.")})")
    }
    private fun cmp(a: String, b: String): Int {
        val x = a.split("."); val y = b.split(".")
        for (i in 0 until maxOf(x.size, y.size)) { val d = (x.getOrNull(i)?.toIntOrNull() ?: 0) - (y.getOrNull(i)?.toIntOrNull() ?: 0); if (d != 0) return d }
        return 0
    }
    private fun checkUpdate(auto: Boolean) = thread {
        try {
            val j = JSONObject(http("https://api.github.com/repos/${BuildConfig.REPO}/releases/latest"))
            val tag = j.getString("tag_name").trim().removePrefix("v")
            val a = j.getJSONArray("assets"); var url = ""; var size = 0L
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); if (o.getString("name").endsWith(".apk")) { url = o.getString("browser_download_url"); size = o.getLong("size") } }
            val r = JSONObject().put("ok", true).put("newer", url.isNotEmpty() && cmp(tag, BuildConfig.VERSION_NAME) > 0).put("ver", tag).put("cur", BuildConfig.VERSION_NAME).put("url", url).put("size", size).put("auto", auto)
            runUi("updInfo($r)")
        } catch (e: Exception) { runUi("updInfo({ok:false,auto:$auto})") }
    }
    private fun installUpdate(url: String) = runOnUiThread {
        if (!packageManager.canRequestPackageInstalls()) {
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            toast("Allow installs from Glass Browser, then tap Update again"); return@runOnUiThread
        }
        val f = File(getExternalFilesDir(null), "update.apk"); f.delete()
        val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        val id = dm.enqueue(DownloadManager.Request(Uri.parse(url)).setDestinationUri(Uri.fromFile(f)).setTitle("Glass Browser update").setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED))
        val rc = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                if (i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1) != id) return
                unregisterReceiver(this)
                val u = FileProvider.getUriForFile(this@MainActivity, "$packageName.fp", f)
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        registerReceiver(rc, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE), Context.RECEIVER_EXPORTED)
        toast("Downloading update…")
    }
    private fun cacheNow() { tabs.forEach { it.web.clearCache(true) }; cacheDir.walkBottomUp().filter { it != cacheDir }.forEach { it.delete() } }
    private fun clearSites() { val e = sp.edit(); sp.all.keys.filter { it.startsWith("site:") }.forEach { e.remove(it) }; e.apply() }

    /* ---------- activity results / back ---------- */
    override fun onActivityResult(c: Int, r: Int, d: Intent?) {
        when (c) {
            5 -> { fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r, d)); fileCb = null }
            6 -> if (r == RESULT_OK) d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { runUi("go(${q(it)})") }
            10 -> if (r == RESULT_OK) runUi("authDone(1)")
            11 -> if (r == RESULT_OK && d?.data != null) try {
                val o = JSONObject(contentResolver.openInputStream(d.data!!)!!.bufferedReader().readText())
                val e = sp.edit(); val p = o.getJSONObject("prefs"); p.keys().forEach { k -> e.putString(k, p.getString(k)) }; e.apply()
                runUi("restoreLS(${o.getJSONObject("ls")})")
            } catch (e: Exception) { toast("Restore failed") }
        }
    }
    override fun onBackPressed() {
        if (fsView != null) { tabs[cur].web.webChromeClient?.onHideCustomView(); return }
        if (curMode == "page" && tabs[cur].web.canGoBack()) { tabs[cur].web.goBack(); return }
        ui.evaluateJavascript("backUi()") { if (it == "true") finish() }
    }

    /* ---------- JS bridge ---------- */
    inner class Bridge {
        @JavascriptInterface fun settings(): String {
            val o = JSONObject(defs.toString()); sp.all.forEach { (k, v) -> if (defs.has(k)) o.put(k, v.toString()) }; return o.toString()
        }
        @JavascriptInterface fun set(k: String, v: String) {
            sp.edit().putString(k, v).apply()
            runOnUiThread { if (k == "hz") applyHz(); if (k == "addr") layout(); tabs.forEach { applyPrefs(it) } }
        }
        @JavascriptInterface fun insets() = "0,0"
        @JavascriptInterface fun mode(m: String, dp: Int) { runOnUiThread { curMode = m; strip = dp; layout() } }
        @JavascriptInterface fun ready() { pendingUrl?.let { runUi("go(${q(it)})"); pendingUrl = null } }
        @JavascriptInterface fun stats() = blocked
        @JavascriptInterface fun pageBlocked() = pageBlk
        @JavascriptInterface fun filterInfo(): String {
            val ts = sp.getLong("hts", 0L)
            return "${hosts.size + BUILTIN.size} domains · updated " + (if (ts == 0L) "never" else DateFormat.getDateInstance().format(Date(ts)))
        }
        @JavascriptInterface fun updateFilters() { updateFilters(true) }
        @JavascriptInterface fun isDesktop() = tabs.getOrNull(cur)?.let { isDesk(it) } ?: false
        @JavascriptInterface fun version(): String = BuildConfig.VERSION_NAME
        @JavascriptInterface fun checkUpdate() { checkUpdate(false) }
        @JavascriptInterface fun installUpdate(u: String) { installUpdate(u) }
        @JavascriptInterface fun googleSignedIn() = CookieManager.getInstance().getCookie("https://accounts.google.com")?.contains("SID=") == true
        @JavascriptInterface fun googleSignOut() {
            val cm = CookieManager.getInstance()
            for (u in listOf("https://accounts.google.com", "https://www.google.com", "https://myaccount.google.com"))
                cm.getCookie(u)?.split(";")?.forEach { cm.setCookie(u, it.substringBefore("=").trim() + "=; Max-Age=0; Domain=.google.com; Path=/") }
            cm.flush()
        }
        @JavascriptInterface fun defaultState() = getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_BROWSER)
        @JavascriptInterface fun defaultBrowser() { runOnUiThread { try { startActivityForResult(getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_BROWSER), 9) } catch (e: Exception) { startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) } } }
        @JavascriptInterface fun cacheSize() = "%.1f MB".format(cacheDir.walkTopDown().filter { it.isFile }.sumOf { it.length() } / 1048576.0)
        @JavascriptInterface fun usGet(): String = sp.getString("us", "[]")!!
        @JavascriptInterface fun usSet(j: String) { sp.edit().putString("us", j).apply() }
        @JavascriptInterface fun sites(): String {
            val a = JSONArray(); sp.all.forEach { (k, v) -> if (k.startsWith("site:")) a.put(JSONArray().put(k.substring(5)).put(v.toString())) }; return a.toString()
        }
        @JavascriptInterface fun siteRemove(k: String) { sp.edit().remove("site:$k").apply() }
        @JavascriptInterface fun siteClear() { clearSites() }
        @JavascriptInterface fun downloads(): String = sp.getString("dls", "[]")!!
        @JavascriptInterface fun openDownloads() { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        @JavascriptInterface fun nav(u: String) {
            runOnUiThread { val t = tabs[cur]; t.url = u; if (S("dnt") == "1") t.web.loadUrl(u, mapOf("DNT" to "1", "Sec-GPC" to "1")) else t.web.loadUrl(u) }
        }
        @JavascriptInterface fun newTab(p: Int) { runOnUiThread { openTab(p == 1) } }
        @JavascriptInterface fun switchTab(i: Int): Boolean {
            val has = tabs.getOrNull(i)?.url?.isNotEmpty() == true
            runOnUiThread { if (i in tabs.indices) select(i) }; return has
        }
        @JavascriptInterface fun tabsJson(): String {
            val a = JSONArray(); tabs.forEachIndexed { i, t -> a.put(JSONObject().put("title", t.title).put("url", t.url).put("priv", t.priv).put("cur", i == cur).put("thumb", "")) }; return a.toString()
        }
        @JavascriptInterface fun closeTab(i: Int) {
            runOnUiThread {
                if (i !in tabs.indices) return@runOnUiThread
                holder.removeAllViews(); val t = tabs.removeAt(i); t.web.destroy()
                if (tabs.isEmpty()) openTab(false)
                if (i < cur) cur--; cur = cur.coerceIn(0, tabs.size - 1); select(cur)
            }
        }
        @JavascriptInterface fun closeAllTabs(p: Int) {
            runOnUiThread {
                val rm = tabs.filter { it.priv == (p == 1) }; holder.removeAllViews()
                rm.forEach { it.web.destroy() }; tabs.removeAll(rm.toSet())
                if (tabs.isEmpty()) openTab(false); select(0)
            }
        }
        @JavascriptInterface fun resetAll() {
            val e = sp.edit(); defs.keys().forEach { e.remove(it) }; e.apply()
            runOnUiThread { applyHz(); tabs.forEach { applyPrefs(it) }; ui.reload() }
        }
        @JavascriptInterface fun auth() {
            runOnUiThread {
                val i = getSystemService(KeyguardManager::class.java).createConfirmDeviceCredentialIntent("Private tabs", "Unlock to continue")
                if (i == null) runUi("authDone(1)") else startActivityForResult(i, 10)
            }
        }
        @JavascriptInterface fun quit() { runOnUiThread { finish() } }
        @JavascriptInterface fun ai(qq: String) { ai(qq, null) }
        @JavascriptInterface fun summarize() {
            runOnUiThread {
                tabs[cur].web.evaluateJavascript("document.body?document.body.innerText.slice(0,3000):''") { r ->
                    val txt = try { JSONArray("[$r]").getString(0) } catch (e: Exception) { "" }
                    if (txt.isBlank()) runUi("aiReply('Open a page first.')")
                    else ai("Summarize this web page in 5 short bullet points:\n$txt", txt.split(Regex("(?<=[.!?])\\s+")).take(3).joinToString(" "))
                }
            }
        }
        @JavascriptInterface fun back() { runOnUiThread { val w = tabs[cur].web; if (w.canGoBack()) w.goBack() else ui.evaluateJavascript("show('home')", null) } }
        @JavascriptInterface fun fwd() { runOnUiThread { val w = tabs[cur].web; if (w.canGoForward()) w.goForward() } }
        @JavascriptInterface fun reload() { runOnUiThread { tabs[cur].web.reload() } }
        @JavascriptInterface fun share() { runOnUiThread { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, tabs[cur].url), null)) } }
        @JavascriptInterface fun copyLink() { runOnUiThread { (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("url", tabs[cur].url)); toast("Link copied") } }
        @JavascriptInterface fun desktop() {
            runOnUiThread { val t = tabs[cur]; if (isDesk(t)) { t.desk = false; sp.edit().putString("desk", "0").apply() } else t.desk = true; applyPrefs(t); t.web.reload() }
        }
        @JavascriptInterface fun reader() { runOnUiThread { tabs[cur].web.evaluateJavascript(READER, null) } }
        @Suppress("DEPRECATION")
        @JavascriptInterface fun find() { runOnUiThread { tabs[cur].web.showFindDialog(null, true) } }
        @JavascriptInterface fun translate() { runOnUiThread { tabs[cur].web.loadUrl("https://translate.google.com/translate?sl=auto&tl=${Locale.getDefault().language}&u=${enc(tabs[cur].url)}") } }
        @JavascriptInterface fun printPage() {
            runOnUiThread { (getSystemService(PRINT_SERVICE) as PrintManager).print("Page", tabs[cur].web.createPrintDocumentAdapter("Page"), PrintAttributes.Builder().build()) }
        }
        @JavascriptInterface fun voice() {
            runOnUiThread { try { startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM), 6) } catch (e: Exception) { toast("Voice input isn’t available") } }
        }
        @JavascriptInterface fun backup() {
            runOnUiThread {
                ui.evaluateJavascript("JSON.stringify(localStorage)") { r ->
                    try {
                        val p = JSONObject(); sp.all.forEach { (k, v) -> if (!k.startsWith("site:") && k != "hts") p.put(k, v.toString()) }
                        val f = File(cacheDir, "glass-backup.json"); f.writeText(JSONObject().put("ls", JSONObject(JSONArray("[$r]").getString(0))).put("prefs", p).toString())
                        val u = FileProvider.getUriForFile(this@MainActivity, "$packageName.fp", f)
                        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("application/json").putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null))
                    } catch (e: Exception) { toast("Backup failed") }
                }
            }
        }
        @JavascriptInterface fun restore() { runOnUiThread { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 11) } }
        @JavascriptInterface fun languages() { startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        @JavascriptInterface fun notifSettings() { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        @JavascriptInterface fun a11y() { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        @JavascriptInterface fun autofill() {
            try { startActivity(Intent(Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE).setData(Uri.parse("package:android")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { toast("Autofill settings unavailable") }
        }
        @JavascriptInterface fun clearCache() { runOnUiThread { cacheNow() } }
        @JavascriptInterface fun clearData(f: String) {
            runOnUiThread {
                val l = f.split(",")
                if ("cookies" in l) { CookieManager.getInstance().removeAllCookies(null); WebStorage.getInstance().deleteAllData() }
                if ("cache" in l) cacheNow()
                if ("perms" in l) clearSites()
                if ("downloads" in l) sp.edit().remove("dls").apply()
            }
        }
    }
}
