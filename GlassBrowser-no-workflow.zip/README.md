# Glass Browser
Push this repo to GitHub. Actions builds the APK automatically (Actions tab > Build APK > artifact).
OTA updates: push a tag like `v1.1.0` (git tag v1.1.0 && git push --tags). Actions publishes a Release with the APK; installed apps find it under "Settings > Check for updates".
The repo must be public for the update check to work. Keep `glass.keystore`: every update must be signed with the same key.
